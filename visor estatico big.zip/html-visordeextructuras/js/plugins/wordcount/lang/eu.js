﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'eu', {
    WordCount: 'Hitzak:',
    WordCountRemaining: 'Gelditzen diren hitzak',
    CharCount: 'Karaktereak:',
    CharCountRemaining: 'Gelditzen diren karaktereak',
    CharCountWithHTML: 'Karaktereak (HTMLarekin):',
    CharCountWithHTMLRemaining: 'Gelditzen diren karaktereak (HTMLarekin)',
    Paragraphs: 'Paragrafoak:',
    ParagraphsRemaining: 'Gelditzen diren paragrafoak',
    pasteWarning: 'Ezin da edukia itsatsi, onartutako muga gainditu duelako',
    Selected: 'Hautatuta: ',
    title: 'Estatistikak'
});
